
/**
 * Write a description of interface Comparable here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Comparable<T>
{
    public int compareTo(T obj);
}
