
/**
 * Circle class...
 */
public class Circle extends Shape
{
    private double radius;
   
    public Circle(double radius) {
        setType("Circle");
        area = radius * radius * Math.PI;
        perimeter = 2 * radius * Math.PI;
        this.radius = radius;
    }
    
    public double getRadius() {
        return radius;
    }

    public void draw() {
        System.out.println("DrawingC " + getType() + "...");
    }
    
    public String toString() {
        return super.toString() + 
                "\n  Radius: " + getRadius();
    }
    
}
