
/**
 * Rectangle class
 */
public class Rectangle extends Shape
{
    private double length;
    private double width;
    
    public Rectangle(double length, double width) {
        setType("Rectangle");
        this.length = length;
        this.width = width;
        area = length * width;
        perimeter = 2 * (length + width);
    }
  
    public double getLength() {
        return length;
    }
    
    public double getWidth() {
        return width;
    }
    
    public void draw() {
        System.out.println("DrawingR " + getType() + "...");
    }
    
    public String toString() {
        return super.toString() + 
                "\n  " + getLength() + " X " + getWidth();
    }
}
