import java.util.*;

/**
 * Midterm CS162 Spring 19, KEY
 */
public abstract class Shape implements Drawable, Comparable<Shape>
{
    private String type;
    protected double area;
    protected double perimeter;

    protected void setType(String type) {
        this.type = type;
    }

    public double getArea() {
        return area;
    }

    public double getPerimeter() {
        return perimeter;
    }

    public String getType() {
        return type;
    }

    // Comparator for sorting on perimeter  
    public static Comparator<Shape> perimeterOrder() {
        return (a, b) -> (int)(a.getPerimeter() - b.getPerimeter());
    }

    public int compareTo(Shape other) {
        return (int)(this.getArea() - other.getArea());
    }

    public String toString() {
        return getType() + "\n  area: " + Math.round(getArea())
        + "\n  perimeter: " + Math.round(getPerimeter());
    }
}
