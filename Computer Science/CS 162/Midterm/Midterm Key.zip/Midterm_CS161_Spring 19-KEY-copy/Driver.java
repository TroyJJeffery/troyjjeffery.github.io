import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.stream.Stream;

/**
 * Midterm CS 162 Spring 2019 - KEY
 * Driver for testing the Shape classes
 */
public class Driver
{
    public static void main(String[] args) {
        List<Shape> shapes = new ArrayList<>();
        shapes.add(new Circle(3.5));
        shapes.add(new Rectangle(9.0, 3.0));
        shapes.add(new Rectangle(3.0, 10.0));
        shapes.add(new Square(5));
        // Print the list
        printShapes(shapes);
        
        // Sort on area
        Collections.sort(shapes);
        printShapes(shapes);
        
        // Call the draw method on each shape
        //shapes.stream().forEach(p -> p.draw());
        shapes.stream().forEach(Shape::draw);
        System.out.println();
        
        // Sort on perimeter, changes the List
        // Collections.sort(shapes,
        //         (a, b) -> (int)(a.getPerimeter() - b.getPerimeter()));
        // Another way to do it, changes the List
        // Collections.sort(shapes, Shape.perimeterOrder());
        // printShapes(shapes);
        
        // Print sorted on perimeter, does not change the List
        shapes.stream()
                    .sorted(Shape.perimeterOrder())
                    .forEach(System.out::println);
    }

    private static void printShapes(List list) {
        list.stream()
            .forEach(System.out::println); 
        System.out.println();
    }
    
    public static void testing() {
        var i = 10;
        var lst = new ArrayList<Integer>();
        lst.add(3); lst.add(5); lst.add(44);
        
        lst.stream().forEach(System.out::println);
        
    }
}

/*
Sample Output

 Circle
  area: 38
  perimeter: 22
Rectangle
  area: 27
  perimeter: 24
Rectangle
  area: 30
  perimeter: 26
Square
  area: 25
  perimeter: 20

Square
  area: 25
  perimeter: 20
Rectangle
  area: 27
  perimeter: 24
Rectangle
  area: 30
  perimeter: 26
Circle
  area: 38
  perimeter: 22

DrawingS Square...
DrawingR Rectangle...
DrawingR Rectangle...
DrawingC Circle...

Square
  area: 25
  perimeter: 20
Circle
  area: 38
  perimeter: 22
Rectangle
  area: 27
  perimeter: 24
Rectangle
  area: 30
  perimeter: 26

 */
