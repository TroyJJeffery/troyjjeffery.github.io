/**
 * Square class
 */
public class Square extends Rectangle
{
    public Square(double side) {
        super(side, side);
        setType("Square");
    }
    
    @Override
    public void draw() {
        System.out.println("DrawingS " + getType() + "...");
    }
    
    // Uses rectangle toString() method
}